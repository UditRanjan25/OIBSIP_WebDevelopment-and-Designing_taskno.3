const taskForm = document.getElementById('taskForm');
const titleInput = document.getElementById('title');
const descriptionInput = document.getElementById('description');
const pendingTasks = document.getElementById('pendingTasks');
const completedTasks = document.getElementById('completedTasks');

taskForm.addEventListener('submit', function (e) {
  e.preventDefault();

  const title = titleInput.value.trim();
  const desc = descriptionInput.value.trim();

  if (!title || !desc) return;

  const taskItem = createTaskItem(title, desc, false);
  pendingTasks.appendChild(taskItem);

  taskForm.reset();
});

function createTaskItem(title, desc, isComplete) {
  const li = document.createElement('li');
  li.innerHTML = `
    <div>
      <strong>${title}</strong><br/>
      <span>${desc}</span>
    </div>
    <div class="task-buttons">
      ${!isComplete ? '<button class="complete-btn">✔</button>' : ''}
      <button class="delete-btn">X</button>
    </div>
  `;

  const deleteBtn = li.querySelector('.delete-btn');
  deleteBtn.addEventListener('click', () => {
    li.remove();
  });

  const completeBtn = li.querySelector('.complete-btn');
  if (completeBtn) {
    completeBtn.addEventListener('click', () => {
      const completedTask = createTaskItem(title, desc, true);
      completedTasks.appendChild(completedTask);
      li.remove();
    });
  }

  return li;
}
